Popis dat
-----------

Vsechny soubory maji tri sloupce:
1 - cetnost - pocet vyskytu jmena v CR
2 - 1. pad jmena
3 - 5. pad jmena, muze byt vice tvaru oddelenych znakem ':'

Jmena jsou rozdelena na muzska a zenska.

Prijmeni jsou rozdelena podle cetnosti:
- pripona _1 = castejsi prijmeni
- pripona _2 = exoticka prijmeni


Sluzba zpracovani jmen
-----------------------

Na adrese http://www.validace.cz najdete nabidku sluzeb pro zpracovani jmen 
a postovnich adres. 


Puvod dat
------------

Seznam jmen: Ministerstvo vnitra CR
http://www.mvcr.cz/clanek/cetnost-jmen-a-prijmeni-722752.aspx

Zpracovani a doplneni 5. padu: Validace.cz
http://www.validace.cz